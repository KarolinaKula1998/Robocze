<?php
class CalcForm {
	public $k;
	public $b;
	public $n;
} 